package com.phoenix;

public class DosageCalculator {

    public static int calculateDosage(int weight) {
        return weight * 2;
    }
}
